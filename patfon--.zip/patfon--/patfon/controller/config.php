<?php
DEFINE ('DB_USER_1', 'root');
DEFINE ('DB_PASSWORD_1', 'loyboy');
DEFINE ('DB_HOST_1', 'localhost');
DEFINE ('DB_NAME_1', 'patfon_db');
$pdb = mysqli_connect (DB_HOST_1, DB_USER_1, DB_PASSWORD_1, DB_NAME_1);
mysqli_set_charset($pdb, 'utf8');