<?php 
session_start();
include './config/connection.php'; 
/**
if (isset($_POST['pfsubmitadd'])){

    $cat = $_POST['category'];
    $sch = $_POST['sch'];
    if (isset($_POST['sub_cati'])) {
    $subi = $_POST['sub_cati'];//income category
    }
  
  //$incomearray = array("1"=>"Fees","2"=>"Old debt","3"=>"Bus","4"=>"Uniform","5"=>"Canteen","6"=>"Sport Wear","7"=>"Pull Over","8"=>"Car");
    if (isset($_POST['sub_cat'])) {
    $sube = $_POST['sub_cat'];//expenditure category
    $subcat = $_POST['sub_cat2'];//expenditure extra category 2
    }

    $date = $_POST['date_'];//get date_

    $month = date("m", strtotime($date));//get month...

    $amt = $_POST['amt'];//get amount
//check which month the user is in...
        if (isset($month) && ($month >= '8' && $month <= '12') ){
            $term = 1;
        }
        else if (isset($month) && ($month >= '1' && $month <= '4') ){
            $term = 2;
        }
        else if (isset($month) && ($month >= '4' && $month <= '7') ){
            $term = 3;
        }
//check if income category has been selected....
        if (isset($subi)){

           
            $query = ("INSERT INTO income (date_,type_,comment_,amount_,month_,term_,category,school) VALUES ('$date','income','',$amt,$month,$term,$subi,$sch) ");
            $skools = "";
            if (mysqli_query($pdb, $query)) {
                
            $_SESSION['add-data-income'] = "1";
             header("Location: ../index.php"); 
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            }
        }
//check if expenditure is been selected....
        else if (isset($sube)) {

          
            $query = ("INSERT INTO expenditure_ (date_,type_,comment_,amount_,month_,term_,category,sch_id) VALUES ('$date','expenditure','',$amt,$month,$term,$sube,$sch) ");
            $skools = "";
            if (mysqli_query($pdb, $query)) {
               $_SESSION['add-data-expend'] = "1";
                header("Location: ../index.php"); 
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            }
        }

 

}
**/

?>