<?php

require 'config.php';
session_start(); 
  

if (isset($_POST['pfsubmit'])){

    $schname = $_POST['schools'];
    $ses = $_POST['session'];
    $type = $_POST['type'];
    $freq = $_POST['frequency'];

    if (isset($_POST['term'])){
    $term = $_POST['term'];
    }
    else{
        $term = '0';
    }
    if (isset($_POST['month'])){
         $month = $_POST['month'];
    }
    else{
        $month = '0';
    }

//change to index parameters
$arraytype = array("income"=>'1',"expend"=>'2',"income&expend"=>'3');
    
    $_SESSION['pfd'] = array();
    $_SESSION['pfd']['sch'] = $schname;//int
    $_SESSION['pfd']['te'] = $term;//int
    $_SESSION['pfd']['ses'] = $ses;//year
    $_SESSION['pfd']['ty'] = $arraytype[$type];//int
    $_SESSION['pfd']['freq'] = $freq;//string
     
     if (isset($_POST['month'])){
     $_SESSION['pfd']['mnt'] = $month;
     }

     if ($_SESSION['pfd']['freq'] == "daily"){
     header("Location: ../daily.php");
     }

     else if ($_SESSION['pfd']['freq'] == "term") {
   
        if ($term == "1"){ 
            $query = ("SELECT id_ FROM income WHERE date_ like '%$ses%' and (month_ = 8 or month_ = 9 or month_ = 10 or month_ = 11 or month_ = 12 )  ");
            
            $query2 = ("SELECT id_ FROM expenditure_ WHERE date_ like '%$ses%' and (month_ = 8 or month_ = 9 or month_ = 10 or month_ = 11 or month_ = 12 )  ");
            
            $result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
            $result2 = mysqli_query($pdb,$query2) or die(mysqli_error($pdb));

            if (mysqli_num_rows($result) == 0 && mysqli_num_rows($result2) == 0 ){
              $_SESSION['no-data'] = 1 ;
            }
            else{
              unset($_SESSION['no-data']);
            }
              header("Location: ../term1.php");  
        }  
        else if ($term == "2"){
            $query = ("SELECT id_ FROM income WHERE date_ like '%$ses%' and (month_ = 1 or month_ = 2 or month_ = 3 or month_ = 4)  ");
            
            $query2 = ("SELECT id_ FROM expenditure_ WHERE date_ like '%$ses%' and (month_ = 1 or month_ = 2 or month_ = 3 or month_ = 4)  ");
            
            $result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
            $result2 = mysqli_query($pdb,$query2) or die(mysqli_error($pdb));

            if (mysqli_num_rows($result) == 0 && mysqli_num_rows($result2) == 0 ){
              $_SESSION['no-data'] = 1 ;
            }
            else{
              unset($_SESSION['no-data']);
            }
              header("Location: ../term2.php"); 
        }
        else if ($term == "3"){
           $query = ("SELECT id_ FROM income WHERE date_ like '%$ses%' and (month_ = 4 or month_ = 5 or month_ = 6 or month_ = 7)  ");
            
            $query2 = ("SELECT id_ FROM expenditure_ WHERE date_ like '%$ses%' and (month_ = 4 or month_ = 5 or month_ = 6 or month_ = 7)  ");
            
            $result = mysqli_query($pdb,$query) or die(mysqli_error($pdb));
            $result2 = mysqli_query($pdb,$query2) or die(mysqli_error($pdb));

            if (mysqli_num_rows($result) == 0 && mysqli_num_rows($result2) == 0 ){
              $_SESSION['no-data'] = 1 ;
            }
            else{
              unset($_SESSION['no-data']);
            }
              header("Location: ../term3.php"); 
        }
     }
}



?>