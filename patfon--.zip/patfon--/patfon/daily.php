    <?php include 'includes/header.php'; ?>
    <?php  ?>

    <?php include 'functions/index.php'; ?>
    
    <?php include 'template/daily.php'; ?>

    <?php include 'includes/footer.php'; ?>