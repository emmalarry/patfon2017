<?php
DEFINE ('DB_USER', 'root');
DEFINE ('DB_PASSWORD', 'loyboy');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'patfon_db');
$pdb = mysqli_connect (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
mysqli_set_charset($pdb, 'utf8');