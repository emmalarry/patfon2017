<?php  $schools = getschools($pdb); 
 if (isset($_POST['pfsubmitadd'])){

    $cat = $_POST['category'];
    $sch = $_POST['sch'];
    if (isset($_POST['sub_cati'])) {
    $subi = $_POST['sub_cati'];//income category
    }
  
  //$incomearray = array("1"=>"Fees","2"=>"Old debt","3"=>"Bus","4"=>"Uniform","5"=>"Canteen","6"=>"Sport Wear","7"=>"Pull Over","8"=>"Car");
    if (isset($_POST['sub_cat'])) {
    $sube = $_POST['sub_cat'];//expenditure category
    $subcat = $_POST['sub_cat2'];//expenditure extra category 2
    }

    $date = $_POST['date_'];//get date_

    $month = date("m", strtotime($date));//get month...

    $amt = $_POST['amt'];//get amount
//check which month the user is in...
        if (isset($month) && ($month >= '8' && $month <= '12') ){
            $term = 1;
        }
        else if (isset($month) && ($month >= '1' && $month <= '4') ){
            $term = 2;
        }
        else if (isset($month) && ($month >= '4' && $month <= '7') ){
            $term = 3;
        }
//check if income category has been selected....
        if (isset($subi)){


            $query = ("SELECT id_ FROM income WHERE date_ = '$date' AND category = $subi");
            $skools = "";
            $result = mysqli_query($pdb,$query) or die(mysqli_error());
            if (mysqli_num_rows($result) > 0){
            while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                $skools = $r['id_'];
                }
            }

            if (strlen($skools) <= 0){

            $query = ("INSERT INTO income (date_,type_,comment_,amount_,month_,term_,category,school) VALUES ('$date','income','',$amt,$month,$term,$subi,$sch) ");
           
            if (mysqli_query($pdb, $query)) {
                
            $_SESSION['add-data-income'] = "1";
            //  header("Location: add.php"); 
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            } }

            else {

            $query = ("UPDATE income SET amount_ = amount_+$amt WHERE date_ = '$date' and category = $subi ");
          
            if (mysqli_query($pdb, $query)) {
                
            $_SESSION['add-data-income'] = "1";
            //  header("Location: add.php"); 
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            }

            }
        }
//check if expenditure is been selected....
        else if (isset($sube)) {

            $query = ("SELECT id_ FROM  expenditure_ WHERE date_ = '$date' AND category = $sube AND sub_cat = $subcat ");
            $skools = "";
            $result = mysqli_query($pdb,$query) or die(mysqli_error());
            if (mysqli_num_rows($result) > 0){
            while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
                
                $skools = $r['id_'];
                }
            }

            if (strlen($skools) <= 0){

            $query = ("INSERT INTO expenditure_ (date_,type_,comment_,amount_,month_,term_,sub_cat,category,sch_id) VALUES ('$date','expenditure','',$amt,$month,$term,$subcat,$sube,$sch) ");
           
            if (mysqli_query($pdb, $query)) {
               $_SESSION['add-data-expend'] = "1";
              
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            }

            }
            else {

            $query = ("UPDATE expenditure_ SET amount_ = amount_+$amt WHERE date_ = '$date' and category = $sube and sub_cat = $subcat ");
          
            if (mysqli_query($pdb, $query)) {
                
            $_SESSION['add-data-expended'] = "1";
            //  header("Location: add.php"); 
            } else {
                echo "Error: ". "<br>" . mysqli_error($pdb);
            }

            }

        }

 

}
?>
        <!-- 
        ================================================== 
            Search Add Income or Expenditure Search
        ================================================== -->
        <section id="contact-section">
            <div class="container">
                  
                <div class="row">
                     <div class="col-md-6">
                         <div class="map-area">
                            <h2 class="subtitle  wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".3s">Add Entry For Income or Expenditure</h2>
                                <div class="contact-form">

                        <?php  if(isset($_SESSION['add-data-income'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added an Income data.
                            </div>                             
                        <?php unset($_SESSION['add-data-income']); } ?>

                         <?php  if(isset($_SESSION['add-data-expend'])) { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;.You have successfully added an Expenditure data.
                            </div>                             
                        <?php unset($_SESSION['add-data-expend']); } ?>


                                    <form id="" method="post" action="" role="form">
                            <fieldset>
                                    
                                    <hr><p></p>
                                    <div class="form-group " data-wow-duration="500ms" data-wow-delay=".6s">
                                       <label>School &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="sch" class="form-control form-horizontal" required="required">
                                            <?php foreach ($schools as $k=>$v) { 
                                            echo "<option value='$k'>$v</option>";
                                             } ?>
                                        </select>
                                    </div>
                                    <div class="form-cat form-group " data-wow-duration="500ms" data-wow-delay=".6s">
                                       <label>Select Category &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="category" id="sel_cat" class="form-control form-horizontal" required="required">
                                           <option value="">Select....</option>
                                           <option value="income">Income</option>
                                           <option value="expenditure">Expenditure</option>
                                        </select>
                                    </div>
                                    
                                   
                                      <div class="form-subcat-i form-group hide wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1s">
                                        <label>Sub Category &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="sub_cati" id="sel_subcat_i" class="form-control form-horizontal">
                                          
                                        </select>
                                    </div> 

                                    <div class="form-subcat form-group hide wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1s">
                                        <label>Sub Category &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="sub_cat" id="sel_subcat" class="form-control form-horizontal">
                                          
                                        </select>
                                    </div>
                                    
                                    <div class="form-subcat2 form-group hide wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                    <label>Sub Category 2  &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="sub_cat2" id="sel_subcat2"  class="form-control form-horizontal">

                                        </select>
                                    </div>

                                   

                                    <div class=" form-group wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                    <label>Date  &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <input name="date_" id="sel_date" type="date"  class="form-control form-horizontal" required="required">

                                       
                                    </div>

                                     <div class=" form-group wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                    <label>Amount  &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <input name="amt" id="sel_amt" type="number"  class="form-control form-horizontal" required="required">

                                       
                                    </div>

                                    
                                    <div id="submit" class="wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.4s">
                                        <input type="submit" name="pfsubmitadd" id="contact-submit" class="btn btn-default btn-primary" value="Add Entry">
                                    </div>                      
                                     
                                </fieldset>
                                </form>
                            </div>
                           
                        </div>
                    </div>

                    <div class="col-md-6">
                         <div class="map-area">
                            <h2 class="subtitle  wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".3s">Make Report On Data</h2>
                                <div class="contact-form">

                                <a class="btn btn-info btn-block" href="index.php">Click here to Generate Report on Data</a>


                         </div>
                           
                    </div>

                </div>
                


            <div class="row address-details" style="margin: 30px;">
                <div class="col-md-12">
                    <div class="col-md-3">
                        <div class="address wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".3s">
                            <i class="ion-ios-location-outline"></i>
                            <h5>Uyo <br>Nigeria</h5>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="email wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".7s">
                            <i class="ion-ios-email-outline"></i>
                            <p>support@patfon.com<br>support2@patfon.com</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="phone wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".9s">
                            <i class="ion-ios-telephone-outline"></i>
                            <p>+234 052 245 022<br>+234 345 221 999</p>
                        </div>
                    </div>
                    <div class="col-md-3">

                    </div>
                </div>
            </div>
        </div>
    </section>
                <!-- 
        ================================================== 
            Patfon Add Section End
        ================================================== -->

   
     




