<?php  $schools = getschools($pdb); ?>
        <!-- 
        ================================================== 
            Search Patfon Account Search
        ================================================== -->
        <section id="contact-section">
            <div class="container">
                        <?php  if(isset($_SESSION['no-data'])) { ?>
                            <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-anchor"></i>&nbsp;&nbsp;No data exists with those parameters. Please select again.
                            </div>                             
                        <?php unset($_SESSION['no-data']); } ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="block">
                            <h2 class="subtitle wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".3s">Patfon Reporting </h2>
                            <p class="subtitle-des wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".5s">
                              Select the parameters to generate the Report of Term.
                            </p>
                            <div class="contact-form">
                                <form id="" method="post" action="controller/index.php" role="form">
                                   <fieldset>
                                    <h4 class="panel-title"> School Details </h4>
                                    <hr><p></p>
                                    <div class="form-group " data-wow-duration="500ms" data-wow-delay=".6s">
                                       <label>School &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="schools" class="form-control form-horizontal" required="required">
                                            <?php foreach ($schools as $k=>$v) { 
                                            echo "<option value='$k'>$v</option>";
                                             } ?>
                                        </select>
                                    </div>
                                    
                                   
                                    
                                    <div class="form-group wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1s">
                                        <label>Session &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="session" class="form-control form-horizontal" required="required">
                                          
                                           <option value=''> Select... </option>
                                           <option value='2017'> 2017/2018 </option>
                                           <option value='2018'>2018/2019  </option>
                                           

                                        </select>
                                    </div>

                                    

                                    <h4 class="panel-title"> Parameters for Report </h4>
                                    <hr> 
                                    <div class="form-group wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                   <label>Type &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="type" id="type_" class="form-control form-horizontal" required="required">
                                          
                                           <option value=''> Select... </option>
                                           <option value='income'> Income Only </option>
                                           <option value='expend'>Expenditure Only  </option>
                                           <option value='income&expend'>Income and Expenditure Summary </option>
                                          

                                        </select>
                                    </div>
                                  <div class="freq-group form-group wow hide fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                   <label>Frequency &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="frequency" id="freq_" class="form-control form-horizontal">
                                          
                                        </select>
                                    </div>

                                     <div class="term-group form-group hide wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".8s">
                                        <label>Term &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                            <select name="term" id="term_" class="form-control form-horizontal">
                                            
                                            <option value=''> Select... </option>
                                            <option value='1'> 1<sup>st</sup> Term </option>
                                            <option value='2'>2<sup>nd</sup> Term   </option>
                                            <option value='3'>3<sup>rd</sup> Term   </option>

                                            </select>
                                    </div>

                                      <div class="month-group form-group wow hide fadeInDown" data-wow-duration="500ms" data-wow-delay="1.2s">
                                   <label>Month &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                        <select name="month" id="month_" class="form-control form-horizontal">
                                          
                                       

                                        </select>
                                    </div>
                                    
                                    <div id="submit" class="wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1.4s">
                                        <input type="submit" name="pfsubmit" id="contact-submit" class="btn btn-default btn-primary" value="Generate Report">
                                    </div>                      
                                     </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                         <div class="map-area">
                            <h2 class="subtitle  wow fadeInDown" data-wow-duration="500ms" data-wow-delay=".3s">Add Entry For Income or Expenditure</h2>
                                <div class="contact-form">

                                <a class="btn btn-info btn-block" href="add.php">Click here to Add Entry</a>


                         </div>
                           
                    </div>
             </div>
        
        </div>
                


            <div class="row address-details" style="margin: 30px;">
                <div class="col-md-12">
                    <div class="col-md-3">
                        <div class="address wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".3s">
                            <i class="ion-ios-location-outline"></i>
                            <h5> Uyo <br>Nigeria</h5>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="email wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".7s">
                            <i class="ion-ios-email-outline"></i>
                            <p>support@patfon.com<br>support2@patfon.com</p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="phone wow fadeInLeft" data-wow-duration="500ms" data-wow-delay=".9s">
                            <i class="ion-ios-telephone-outline"></i>
                            <p>+234 052 245 022<br>+234 345 221 999</p>
                        </div>
                    </div>
                    <div class="col-md-3">

                    </div>
                </div>
            </div>
        </div>
    </section>
                <!-- 
        ================================================== 
            Patfon Search Section End
        ================================================== -->
     




