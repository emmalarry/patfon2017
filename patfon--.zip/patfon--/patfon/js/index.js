 if ( window.location.href.indexOf("") > -1 || window.location.href.indexOf("index.php") > -1 ) { 
//no use
 }

$(document).ready(function() {
    var sum7 = 0;var sum8 = 0;
    var sum6 = 0;var sum5 = 0;
    var sum4 = 0;var sum3 = 0; 
    var sum2 = 0; var sum= 0;
   
    $('.pf_ex1').each(function () {
        var _total = Number($(this).text());
        sum = sum + _total;
    });
    $("#total1").text(sum.toFixed(2));
    
    $('.pf_ex2').each(function () {
        var _total = Number($(this).text());
        sum2 = sum2 + _total;
    });
      $("#total2").text(sum2.toFixed(2));

    $('.pf_ex3').each(function () {
        var _total = Number($(this).text());
        sum3 = sum3 + _total;
    });
    $("#total3").text(sum3.toFixed(2));

    //
    $('.pf_ex4').each(function () {
        var _total = Number($(this).text());
        sum4 = sum4 + _total;
    });
    $("#total4").text(sum4.toFixed(2));
    
    $('.pf_ex5').each(function () {
        var _total = Number($(this).text());
        sum5 = sum5 + _total;
    });
      $("#total5").text(sum5.toFixed(2));

    $('.pf_ex6').each(function () {
        var _total = Number($(this).text());
        sum6 = sum6 + _total;
    });
    $("#total6").text(sum6.toFixed(2));

   $('.pf_ex7').each(function () {
        var _total = Number($(this).text());
        sum7 = sum7 + _total;
    });
    $("#total7").text(sum7.toFixed(2));

   //add each row
   $('#exp_table tbody tr').each(function () {
        //the value of sum needs to be reset for each row, so it has to be set inside the row loop
        var sum = 0
        //find the combat elements in the current row and sum it 
        $(this).find('.pf_row').each(function () {
            var combat = $(this).text();
            if (!isNaN(combat) && combat.length !== 0) {
                sum += parseFloat(combat);
            }
        });
        //set the value of currents rows sum to the total-combat element in the current row
        $('.pf_total_v', this).html(sum.toLocaleString());
    });

     //add each row
   $('#inc_table tbody tr').each(function () {
        //the value of sum needs to be reset for each row, so it has to be set inside the row loop
        var sum = 0
        //find the combat elements in the current row and sum it 
        $(this).find('.pf_row_i').each(function () {
            var combat = $(this).text();
            if (!isNaN(combat) && combat.length !== 0) {
                sum += parseFloat(combat);
            }
        });
        //set the value of currents rows sum to the total-combat element in the current row
        $('.pf_total_vi', this).html(sum.toLocaleString());
    });

     $('.pf_total_v').each(function () {
        var _total = Number($(this).text());
        sum8 = sum8 + _total;
    });
    $("#total8").text(sum8.toFixed(2));

    } );



$(document).on('change', '#type_', function (e) {
    var typeofincome = $(this).val();
   
    if (typeofincome === "income"){
       $('.freq-group').removeClass('hide');   
        $('#freq_').attr("required","required");   
       $(".freqclass").remove();
       $("#freq_").append("<option class='freqclass' value=''> Select...</option><option class='freqclass' value='daily'> Daily report </option>");
       $('.term-group').addClass('hide'); 
    }
   else if (typeofincome === "expend"){
         $('.term-group').addClass('hide'); 
          $('#freq_').attr("required","required");   
        $(".freqclass").remove();
        $('.freq-group').removeClass('hide');  
        $("#freq_").append("<option class='freqclass' value=''> Select...</option><option class='freqclass' value='daily'> Daily report </option>");
   }
   else if (typeofincome === "income&expend"){
        $(".freqclass").remove();
        $('.freq-group').removeClass('hide'); 
         $('#freq_').attr("required","required");    
        $("#freq_").append("<option class='freqclass' value=''> Select...</option><option class='freqclass' value='term'>Terminal report </option>");
  
   }
   else{
       $('.freq-group').addClass('hide'); 
        $('#freq_').removeAttr("required");  
       $('.month-group').addClass('hide');  

   }

   
   });


//
   $(document).on('change', '#freq_', function (e) {
    //check if daily or term option is chodsen
     console.log("Changed to daily");
     var frequency = $(this).val();
     
     if (frequency === "daily"){

       $('.term-group').addClass('hide'); 
        $('#term_').removeAttr("required"); 

       $('.month-group').removeClass('hide');  
       $('#month_').attr("required","required"); 
       $(".monthclass").remove();
       $("#month_").append("<option class='monthclass' value=''> Select...</option> <option value='1' class='monthclass'> January </option><option class='monthclass' value='2'> February </option><option class='monthclass' value='3'> March </option><option class='monthclass' value='4'> April </option><option class='monthclass' value='5'> May </option><option class='monthclass' value='6'> June </option><option class='monthclass' value='7'> July </option><option class='monthclass' value='8'> August </option><option class='monthclass' value='9'> September </option> <option value='10' class='monthclass'> October </option><option class='monthclass' value='11'> November </option><option class='monthclass' value='12'> December </option>");
      
    }
    else if (frequency === "term"){
        $(".monthclass").remove();
        $('.month-group').addClass('hide');
        $('#month_').removeAttr("required");   
        $('#term_').attr("required","required");  
        $('.term-group').removeClass('hide');  
     }

   });
    
    
    
    //
   $(document).on('change', '#sel_cat', function (e) {
   var cat = $(this).val();

    if (cat === "income"){

       $('.form-subcat-i').removeClass('hide');
        $('.form-subcat').addClass('hide'); 
       $(".subclass2").remove();$(".subclass").remove();
       $('#sel_subcat_i').attr("required","required");  
       $('#sel_subcat').removeAttr("required"); 
        
       $("#sel_subcat_i").append("<option class='subclass' value=''> Select...</option> <option value='1' class='subclass'> Fees</option><option class='subclass' value='2'> Old Debt </option><option class='subclass' value='3'> Bus </option><option class='subclass' value='4'> Uniform</option><option class='subclass' value='5'> Canteen </option><option class='subclass' value='6'> Sport Wear </option><option class='subclass' value='7'> Pull Over </option><option class='subclass' value='8'> Car </option>");
      
    }

    else if (cat === "expenditure"){
      
       $('.form-subcat').removeClass('hide'); 
       $('.form-subcat-i').addClass('hide');
       $(".subclass").remove();
       $('#sel_subcat').attr("required","required");
       $('#sel_subcat_i').removeAttr("required");   

       $("#sel_subcat").append("<option class='subclass2' value=''> Select...</option> <option value='1' class='subclass2'> Salary</option><option class='subclass2' value='2'> Recurrent Expenditure </option><option class='subclass2' value='3'> Repairs/Maintenance </option> <option class='subclass2' value='4'> Creditors</option><option class='subclass2' value='5'> Petty Cash </option><option class='subclass2' value='6'> Capital Expediture </option><option class='subclass2' value='7'> Director </option>");
      
    }
    else{
       $('.form-subcat').addClass('hide');   $('.form-subcat-i').addClass('hide'); 
       $(".subclass").remove(); $(".subclass2").remove();
        $('#sel_subcat').removeAttr("required");   $('#sel_subcat_i').removeAttr("required");  
    }

   });


    $(document).on('change', '#sel_subcat', function (e) {
     var cat = $(this).val();
      if (cat === "1"){
            $('.form-subcat2').removeClass('hide'); 
            $(".subclass3").remove();
             $('#sel_subcat2').attr("required","required");  
            $("#sel_subcat2").append("<option class='subclass3' value=''> Select...</option> <option value='1' class='subclass3'> Teacher Wages</option>");
            
      }
      else if (cat === "2"){
           $('.form-subcat2').removeClass('hide'); 
            $(".subclass3").remove();
             $('#sel_subcat2').attr("required","required");  
            $("#sel_subcat2").append("<option class='subclass3' value=''> Select...</option> <option value='2' class='subclass3'> Operational Lincense </option><option value='3' class='subclass3'> Chalk </option><option value='4' class='subclass3'> White Board Marker </option><option value='5' class='subclass3'> Power Bills </option><option value='6' class='subclass3'> Sanitary Materials </option><option value='7' class='subclass3'> Internet Bills </option><option value='8' class='subclass3'> Stationaries </option><option value='9' class='subclass3'> Printing </option><option value='10' class='subclass3'> Fueling </option><option value='11' class='subclass3'> Instructional Materials </option><option value='12' class='subclass3'> Medical </option>");
            
      }
      else if (cat === "3"){
           $('.form-subcat2').removeClass('hide'); 
            $(".subclass3").remove();
             $('#sel_subcat2').attr("required","required");  
            $("#sel_subcat2").append("<option class='subclass3' value=''> Select...</option> <option value='13' class='subclass3'> Photocopier </option><option value='14' class='subclass3'> Plumbing Fitting </option><option value='15' class='subclass3'> Electrical Maintenance </option><option value='16' class='subclass3'>Generator </option><option value='17' class='subclass3'> Furniture </option><option value='18' class='subclass3'> Painting </option><option value='19' class='subclass3'> Computer Maintenance </option>");
            
      }
     

       else if (cat === "4"){
           $('.form-subcat2').removeClass('hide'); 
            $(".subclass3").remove();
            $("#sel_subcat2").append("<option class='subclass3' value=''> Select...</option> <option value='21' class='subclass3'> Transportation </option><option value=22' class='subclass3'> Recharge Card </option><option value='23' class='subclass3'> Entertainment </option><option value='24' class='subclass3'>Public Relations </option>");
            
      }

       else if (cat === "5"){
           $('.form-subcat2').removeClass('hide'); 
            $(".subclass3").remove();
            $("#sel_subcat2").append("<option class='subclass3' value=''> Select...</option> <option value='24' class='subclass3'> Computer Purchase</option><option value=25' class='subclass3'> Patfon University </option><option value='26' class='subclass3'> Patitioning of Class </option><option value='27' class='subclass3'>Land Payment</option>");
            
      }

    });