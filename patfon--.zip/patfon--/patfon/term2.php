<?php include 'includes/header.php'; ?>
    <?php  ?>

    <?php include 'functions/index.php'; ?>
    
    <?php include 'template/term2.php'; ?>

    <?php include 'includes/footer.php'; ?>