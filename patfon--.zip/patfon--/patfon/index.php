
<?php include 'includes/header.php'; ?>

<?php include 'functions/index.php'; ?>

<?php include 'pages/search.php'; ?>

<?php include 'includes/footer.php'; ?>
    
   