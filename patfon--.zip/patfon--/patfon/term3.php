<?php include 'includes/header.php'; ?>
    <?php  ?>

    <?php include 'functions/index.php'; ?>
    
    <?php include 'template/term3.php'; ?>

    <?php include 'includes/footer.php'; ?>