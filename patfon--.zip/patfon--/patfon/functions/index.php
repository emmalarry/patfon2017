<?php 
$firstterm = array(9,10,11,12);//months of 1st term
$secondterm = array(1,2,3,4);
$thirdterm = array(5,6,7,8);

function getschools($con){

$query = ("SELECT name_,id_ FROM school");
$skools = array();
$result = mysqli_query($con,$query) or die(mysqli_error());
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $skools[$r['id_']] = $r['name_'];
    }
 }

 return $skools;

}

function getschoolname($con,$id){

$query = ("SELECT name_ FROM school WHERE id_ = $id ");
$skools = "";
$result = mysqli_query($con,$query) or die(mysqli_error());
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $skools = $r['name_'];
    }
 }

 return $skools;

}

function getdistinctdates_income($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_ FROM income WHERE month_ = $month AND date_ LIKE '%$year%' AND school = $sch ORDER BY date_ ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_'];
    }
 }
 return $dates;

}

function getdistinctdates_expend($con,$month,$year,$sch) {
  $query = ("SELECT DISTINCT date_ FROM expenditure_ WHERE month_ = $month AND date_ LIKE '%$year%' AND sch_id = $sch ORDER BY date_ ");
$dates = array();
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $dates[] = $r['date_'];
    }
 }
 return $dates;

}

function getincomefee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount_ FROM income WHERE category = $type AND date_ = '$datex' AND month_ = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount_'];
    }
 }
 return $fees;

}

function getexpendfee($con,$type,$month,$datex,$sch) {
$query = ("SELECT amount_ FROM expenditure_ WHERE category = $type AND date_ = '$datex' AND month_ = $month AND sch_id = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['amount_'];
    }
 }
 return $fees;

}

function getincomesum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount_) as myamt FROM income WHERE category = $type AND date_ LIKE '%$datex%' AND month_ = $month AND school = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}

function getexpendsum($con,$type,$month,$datex,$sch) {
$query = ("SELECT SUM(amount_) as myamt FROM expenditure_ WHERE sub_cat = $type AND date_ LIKE '%$datex%' AND month_ = $month AND sch_id = $sch ");
$fees = "";
$result = mysqli_query($con,$query) or die(mysqli_error($con));
 if (mysqli_num_rows($result) > 0){
   while ($r = mysqli_fetch_array ($result, MYSQLI_ASSOC)) { 
    
     $fees = $r['myamt'];
    }
 }
 return $fees;

}




?>