 <?php include 'includes/header.php'; ?>
    <?php  ?>

    <?php include 'functions/index.php'; ?>
    
    <?php include 'pages/add.php'; ?>

    <?php include 'includes/footer.php'; ?>