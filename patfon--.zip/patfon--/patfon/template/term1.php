

<div class="col-md-12">

<div class="row" > 
<div>
<h2> School Name: 
<?php echo getschoolname($pdb,$_SESSION['pfd']['sch']); ?> </h2>
<div>
<div ><a class="btn btn-block btn-success" href="index.php">Go back to Report Page</a>
</div></div>


<br>
<h4> Monthly Status of proposed Income/expenditure for First term in <?php  echo $_SESSION['pfd']['ses']."/".(intval($_SESSION['pfd']['ses'])+1); ?> session </h4>

<?php if (!isset($_SESSION['no-data']))
{ ?>
    <table id="example2" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
                <thead>
                <tr role="row">
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending"></th>
				
                <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending"></th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Proposed</th>
                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">August</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">Sept</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">October</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">November</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">December</th>
				
				</tr>
                </thead>
                <tbody>    

                <tr role="row" class="odd" style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">INCOME</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">Balance BF</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">FEES</th>
                  <td></td>
                   <td><?php echo getincomesum($pdb,1,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getincomesum($pdb,1,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr><tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">OLD DEPT</th>
                  <td></td>
                  <td><?php echo getincomesum($pdb,2,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getincomesum($pdb,2,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">DIRECTOR'S CONTRIBUTION</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                  <td></td>
                </tr><tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd"  style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">EXPENDITURE</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="even">
				<td>A</td>
                  <th class="sorting_1">SALARY/WAGES</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td>
                  
                </tr><tr role="row" class="odd">
				<td>i.</td>
                  <td class="sorting_1">SALARY</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,1,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,1,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td>B</td>
                  <th class="sorting_1">RECURRENT EXPN.</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td>i</td>
                  <td class="sorting_1">Operational licence</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,2,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,2,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,2,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,2,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,2,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>ii</td>
                  <td class="sorting_1">chalk</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,3,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,3,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,3,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,3,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,3,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				
				<tr role="row" class="even">
				<td>iii</td>
                  <td class="sorting_1">whiteboard marker</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,4,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,4,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,4,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,4,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,4,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>iv</td>
                  <td class="sorting_1">power bills</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,5,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,5,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,5,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,5,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,5,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>v</td>
                  <td class="sorting_1">sanitary materials</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,6,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,6,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,6,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,6,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,6,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>vi</td>
                  <td class="sorting_1">Internet  bills</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,7,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,7,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,7,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,7,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,7,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>vii</td>
                  <td class="sorting_1">stationaries</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,8,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,8,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,8,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,8,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,8,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>viii</td>
                  <td class="sorting_1">Printing</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,9,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,9,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,9,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				  <td><?php echo getexpendsum($pdb,9,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                  <td><?php echo getexpendsum($pdb,9,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>ix</td>
                  <td class="sorting_1">Fueling</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,10,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,10,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,10,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,10,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,10,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td>x</td>
                  <td class="sorting_1">Instructional Material</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,11,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,11,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,11,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,11,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,11,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
                <tr role="row" class="odd">
				<td>x</td>
                  <td class="sorting_1">Medical</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,12,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,12,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,12,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,12,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,12,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				</tbody>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>C</td>
                  <th class="sorting_1">REPAIRS/MAINTANANCE.</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Photocopier</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,13,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,13,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,13,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,13,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,13,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Plumbing</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,14,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,14,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,14,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,14,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,14,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Electrical Maintanance</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,15,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,15,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,15,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,15,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?> </td> 
                   <td><?php echo getexpendsum($pdb,15,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?> </td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Generator</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,16,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,16,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,16,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,16,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,16,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Furniture/fittings</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,17,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,17,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,17,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,17,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 

                   <td><?php echo getexpendsum($pdb,17,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Painting</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,18,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,18,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,18,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,18,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,18,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Computer Maintanance</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,19,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,19,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,19,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,19,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                    <td><?php echo getexpendsum($pdb,19,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">others</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> 
                   <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>D</td>
                  <th class="sorting_1">CREDITORS</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Auditors Charge</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">welfare</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Solo printer</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Loan payment</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Chieve Asuquo</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">other creditors</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
                
				 <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>E</td>
                  <th class="sorting_1">PETTY CASH</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Transportation</td>
                   <td></td>
                  <td><?php echo getexpendsum($pdb,20,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,20,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,20,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,20,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,20,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Recharge card</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,21,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,21,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,21,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,21,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,21,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Entertainment</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,22,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,22,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,22,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,22,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,22,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">public relations</td>
                  <td></td>
                 <td><?php echo getexpendsum($pdb,23,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,23,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,23,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,23,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,23,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				
            	<tr role="row" class="even">	 
				 <td>F</td>
                  <th class="sorting_1">CAPITAL EXPENSES</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Computer purchase</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,24,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,24,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,24,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,24,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,24,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Patfon university</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,25,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,25,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,25,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,25,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,25,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">partitioning of class</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,26,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,26,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,26,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,26,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,26,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">land payment</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,27,8,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,27,9,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,27,10,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,27,11,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                   <td><?php echo getexpendsum($pdb,27,12,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>G</td>
                  <th class="sorting_1">DIRECTORS EXPENSES</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">chairman</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director1</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 2</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 3</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 4</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 5</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
                <tfoot>
                <tr>
				 <td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td> <td></td>
				</tr>
                
                </tfoot>
              </table>
              <?php } else { ?>

            <table class="table table-striped">
            <tbody>
            <tr >
            <td colspan="4"> <h3> <b>No data available to use to display Report </b></h3></td> 
            <td colspan="2"><a class="btn btn-block btn-success" href="index.php">Go back to Report Page</a></td>
            </tr>
            </tbody>
            </table>

              <?php } ?>
              </div>

           

