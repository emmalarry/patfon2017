

<div class="col-md-12">
<div class="row" > 
<div>
<h2> School Name: 
<?php echo getschoolname($pdb,$_SESSION['pfd']['sch']); ?> </h2>
<div>
<div ><a class="btn btn-block btn-success" href="index.php">Go back to Report Page</a>
</div></div>
<br>
<h4> Monthly Status of proposed Income/expenditure for Third term in <?php  echo $_SESSION['pfd']['ses']."/".(intval($_SESSION['pfd']['ses'])+1); ?> session </h4>
    <?php if (!isset($_SESSION['no-data']))
{ ?>
    <table id="example2" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
                <thead>
                <tr role="row">
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending"></th>
				
                <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending"></th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">Proposed</th>
                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Browser: activate to sort column ascending">April</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Platform(s): activate to sort column ascending">May</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Engine version: activate to sort column ascending">June</th>
				<th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="CSS grade: activate to sort column ascending">July</th>
				
				</tr>
                </thead>
                <tbody>    

                <tr role="row" class="odd" style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">INCOME</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
                <tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">Balance BF</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">FEES</th>
                  <td></td>
                   <td><?php echo getincomesum($pdb,1,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,1,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				  
                </tr><tr role="row" class="even">
				<td></td>
                  <th class="sorting_1">OLD DEPT</th>
                  <td></td>
                  <td><?php echo getincomesum($pdb,2,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getincomesum($pdb,2,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				  
                </tr><tr role="row" class="odd">
				<td></td>
                  <th class="sorting_1">DIRECTOR'S CONTRIBUTION</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                  <td></td>
                </tr><tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="odd"  style="background: #000; color: #fff;">
				<td></td>
                  <th class="sorting_1">EXPENDITURE</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr><tr role="row" class="even">
				<td>A</td>
                  <th class="sorting_1">SALARY/WAGES</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td>
                  
                </tr><tr role="row" class="odd">
				<td>i.</td>
                  <td class="sorting_1">SALARY</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,1,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,1,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				</tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td>B</td>
                  <th class="sorting_1">RECURRENT EXPN.</th>
                  <td></td>
                   <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td>i</td>
                  <td class="sorting_1">Operational licence</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,2,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,2,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,2,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,2,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td>ii</td>
                  <td class="sorting_1">chalk</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,3,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,3,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,3,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,3,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				
				<tr role="row" class="even">
				<td>iii</td>
                  <td class="sorting_1">whiteboard marker</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,4,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,4,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,4,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,4,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                
                </tr>
				<tr role="row" class="even">
				<td>iv</td>
                  <td class="sorting_1">power bills</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,5,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,5,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,5,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,5,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td>v</td>
                  <td class="sorting_1">sanitary materials</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,6,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,6,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,6,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,6,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td>vi</td>
                  <td class="sorting_1">Internet  bills</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,7,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,7,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,7,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,7,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td>vii</td>
                  <td class="sorting_1">stationaries</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,8,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,8,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,8,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,8,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 
                </tr>
				<tr role="row" class="even">
				<td>viii</td>
                  <td class="sorting_1">Printing</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,9,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,9,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,9,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				  <td><?php echo getexpendsum($pdb,9,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td>ix</td>
                  <td class="sorting_1">Fueling</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,10,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,10,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,10,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,10,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td>x</td>
                  <td class="sorting_1">Instructional Material</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,11,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,11,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,11,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,11,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
                <tr role="row" class="odd">
				<td>x</td>
                  <td class="sorting_1">Medical</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,12,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,12,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,12,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,12,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				</tbody>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>C</td>
                  <th class="sorting_1">REPAIRS/MAINTANANCE.</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Photocopier</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,13,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,13,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,13,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,13,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Plumbing</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,14,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,14,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,14,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,14,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Electrical Maintanance</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,15,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,15,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,15,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,15,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?> </td> 
                 </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Generator</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,16,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,16,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,16,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,16,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                  </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Furniture/fittings</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,17,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,17,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,17,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,17,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 

                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Painting</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,18,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,18,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,18,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,18,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
         
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Computer Maintanance</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,19,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,19,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,19,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,19,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">others</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> 
                   <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>D</td>
                  <th class="sorting_1">CREDITORS</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Auditors Charge</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">welfare</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Solo printer</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Loan payment</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Chieve Asuquo</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">other creditors</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
                
				 <tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>E</td>
                  <th class="sorting_1">PETTY CASH</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Transportation</td>
                   <td></td>
                  <td><?php echo getexpendsum($pdb,20,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,20,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,20,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,20,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Recharge card</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,21,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,21,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,21,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,21,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Entertainment</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,22,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,22,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,22,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,22,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">public relations</td>
                  <td></td>
                 <td><?php echo getexpendsum($pdb,23,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,23,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,23,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,23,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				
            	<tr role="row" class="even">	 
				 <td>F</td>
                  <th class="sorting_1">CAPITAL EXPENSES</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Computer purchase</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,24,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,24,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,24,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,24,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Patfon university</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,25,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,25,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,25,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,25,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">partitioning of class</td>
                  <td></td>
                   <td><?php echo getexpendsum($pdb,26,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,26,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,26,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,26,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">land payment</td>
                  <td></td>
                  <td><?php echo getexpendsum($pdb,27,4,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,27,5,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
                  <td><?php echo getexpendsum($pdb,27,6,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td>
				   <td><?php echo getexpendsum($pdb,27,7,$_SESSION['pfd']['ses'],$_SESSION['pfd']['sch']); ?></td> 
                 </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1"></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td>G</td>
                  <th class="sorting_1">DIRECTORS EXPENSES</th>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">chairman</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director1</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 2</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				  <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 3</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 4</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
				<tr role="row" class="even">
				<td></td>
                  <td class="sorting_1">Director 5</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
				   <td></td> <td></td>
                </tr>
                <tfoot>
                <tr>
				 <td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td> <td></td>
				</tr>
                
                </tfoot>
              </table>
            <?php } else { ?>

            <table class="table table-striped">
            <tbody>
            <tr>
            <td colspan="4"> <h3> <b>No data available to use to display Report </b></h3></td> 
            <td colspan="2"><a class="btn btn-block btn-success" href="index.php">Go back to Report Page</a></td>
            </tr>
            </tbody>
            </table>

            <?php } ?>
              </div>

           

