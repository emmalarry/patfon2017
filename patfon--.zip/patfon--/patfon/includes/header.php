<?php session_start(); 
include './config/connection.php'; ?>

<!DOCTYPE html>
<html class="no-js">
    <head>
        <!-- Basic Page Needs
        ================================================== -->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="icon" type="image/png" href="images/favicon.png">
        <title>PATFON School Management System</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <!-- Mobile Specific Metas
        ================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Template CSS Files
        ================================================== -->
        <!-- bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
         <!-- animate css -->
        <link rel="stylesheet" href="css/animate.css">
         <!-- Ionicons Fonts Css -->
        <link rel="stylesheet" href="css/ionicons.min.css">
        <!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
        <!-- Custom css -->
        <link rel="stylesheet" href="css/style/header/styles.css">
          <!-- Custom css -->
        <link rel="stylesheet" href="css/style/styles.css">
           <!-- jquery -->
        <script src="js/jquery-2.1.4.min.js"></script>
        <script src="js/index.js"></script>
           <!-- bootstrap js -->
        <script src="js/bootstrap.min.js"></script>
        
       
    </head>
    <body>
        <!--
        ==================================================
        Header Section Start
        ================================================== -->
        <header>
       
        
        </header>
      
